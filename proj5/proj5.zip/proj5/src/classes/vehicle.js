export class Vehicle {
    constructor(license, model, latLong) {
        this.license = license;
        this.model = model;
        this.latLong = latLong;
    }
}